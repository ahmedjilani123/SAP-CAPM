const GetData = require("./controller/GetData");
const SingleDelteSrv = require("./controller/SingleDeleteSrv");
const SingleGetData = require("./controller/SingleGetData");
const SingleUpdateSrv = require("./controller/SingleUpdateSrv");
module.exports=function(srv){
    srv.on("READ","User",GetData);
    srv.on("UPDATE","Userupdate",SingleUpdateSrv);
    srv.on("DELETE","Userdelete",SingleDelteSrv);
    srv.on("READ","UserSingle",SingleGetData);
}