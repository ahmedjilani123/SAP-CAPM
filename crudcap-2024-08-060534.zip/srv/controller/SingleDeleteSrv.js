const cds= require("@sap/cds")
const {User} = cds.entities("users");

const SingleDelteSrv=async function(req,res){
    const data=await SELECT.from(User)
    return data;
}
module.exports=SingleDelteSrv