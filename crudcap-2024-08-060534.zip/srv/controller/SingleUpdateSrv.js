const cds = require("@sap/cds");
const { User } = cds.entities("users");
const SingleUpdateSrv = async (req)=>{
  const getData = req.data
  const data = await SELECT.from(User).where({ ID: getData.ID })
  if (!data.length) {
    req.error({ message: "data is not exist", code: 404 });
    return data;
  } else {
    const update = await UPDATE(User).set(getData).where({ ID: getData.ID })
    req.notify({ message: "Updated", code: 201 });
    return update;
  }
}
module.exports = SingleUpdateSrv;