const cds= require("@sap/cds")
const {User} = cds.entities("users");


const SingleGetData=async function(req,res){
    const data=await SELECT.from(User)
    return data;
}
module.exports=SingleGetData